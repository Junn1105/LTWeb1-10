# BT Giữa Kỳ - Nguyễn Phước Sang - 24110053

Ứng dụng quản lý thư viện sử dụng Servlet, JSP, JPA/Hibernate, SQL Server và SiteMesh.

## Chuẩn bị dữ liệu

1. Mở SQL Server Management Studio và tạo database `BaiTapGiuaKy`.
2. Chạy lần lượt `database/create_baitapgiuaky_tables.sql` và `database/seed_baitapgiuaky_data.sql`.
3. Mặc định ứng dụng kết nối SQL Server tại `localhost:1433` bằng Windows Authentication. Có thể ghi đè bằng biến môi trường:
   - `DB_URL`
   - `DB_USER`
   - `DB_PASSWORD`

## Gửi OTP email thật

Cấu hình các biến môi trường `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM`. Nếu chưa cấu hình SMTP, mã OTP được hiển thị ở màn hình xác thực để có thể kiểm thử đầy đủ luồng đăng ký.

## Tài khoản có sẵn

- Admin: `nguyenphuocsang1105@gmail.com` / `123456`
- User kiểm thử: `nguyenphuocsang1105+user@gmail.com` / `123456`
- User: `hoang.le@example.com` / `123456`

## Chạy project

Project WAR không có file `main()` để chạy trực tiếp. Trong IntelliJ IDEA:

1. Chọn **Run > Edit Configurations > + > Tomcat Server > Local**.
2. Chọn Application Server: `D:\LT Web\apache-tomcat-10.1.44\apache-tomcat-10.1.44`.
3. Tại **Deployment**, thêm artifact `BTGiuaKy:war exploded`.
4. Tại **VM options**, thêm `-Djava.library.path="D:\LT Web\sqlserver-auth"` để Windows Authentication kết nối SQL Server.
5. Chạy cấu hình Tomcat và mở `http://localhost:8080/BTGiuaKy/home`.

Có thể đóng gói thủ công bằng `mvn clean package`; file triển khai nằm tại `target/BTGiuaKy.war`.

Nếu không có Tomcat Server, chạy `run-tomcat.bat` ở thư mục gốc project. Dùng `stop-tomcat.bat` để dừng máy chủ.
